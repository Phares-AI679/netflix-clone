const firebaseConfig = {
  apiKey: "AIzaSyC3QZlCbG63L4SqMO4IFIy9VG8XB459BIw",
  authDomain: "netflix-clone-70644.firebaseapp.com",
  projectId: "netflix-clone-70644",
  storageBucket: "netflix-clone-70644.appspot.com",
  messagingSenderId: "402019649562",
  appId: "1:402019649562:web:d10b8bafb068c191b429a3",
  measurementId: "G-CC4Y04E0G4",
};
